package Javabean;

public class bean {

	public bean() {
		// TODO Auto-generated constructor stub
	}
    private String zhanming;
    private String xianluhao;
	public String getZhanming() {
		return zhanming;
	}
	public void setZhanming(String zhanming) {
		this.zhanming = zhanming;
	}
	public String getXianluhao() {
		return xianluhao;
	}
	public void setXianluhao(String xianluhao) {
		this.xianluhao = xianluhao;
	}
    
    
}
